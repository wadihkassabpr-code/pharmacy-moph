@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ============================================================
echo Pharmacy MOPH - Daily update at 07:00 AM (NO ADMIN NEEDED)
echo ============================================================
echo.

set "SITE_ID=470d2b0b-4cbc-446f-970d-cacf22480f9c"
set "AUTODIR=%LOCALAPPDATA%\PharmacyMophAutoUpdate"
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "STARTFILE=%STARTUP%\PharmacyMophAutoUpdate.cmd"

if not exist "%AUTODIR%" mkdir "%AUTODIR%" >nul 2>&1
if not exist "%STARTUP%" mkdir "%STARTUP%" >nul 2>&1

>"%AUTODIR%\project-path.txt" echo %CD%
copy /Y "%~dp0tools\auto-update-worker.ps1" "%AUTODIR%\worker.ps1" >nul

REM Remove old per-user scheduled tasks if they exist. Failure is harmless.
schtasks /Delete /TN "Pharmacy MOPH Daily Update" /F >nul 2>&1
schtasks /Delete /TN "Pharmacy MOPH Update Catchup" /F >nul 2>&1

REM Link this folder to the existing Netlify site. This does not need Administrator rights.
echo [1/4] Linking this folder to Netlify...
call npx --yes netlify-cli link --id %SITE_ID%
if errorlevel 1 (
  echo.
  echo LINK FAILED. Make sure you are logged in to Netlify, then run this file again.
  pause
  exit /b 1
)

REM Install a launcher in the CURRENT USER Startup folder. No elevation required.
echo.
echo [2/4] Installing the 07:00 updater for this Windows user...
>"%STARTFILE%" echo @echo off
>>"%STARTFILE%" echo powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%%LOCALAPPDATA%%\PharmacyMophAutoUpdate\worker.ps1"

REM Start the hidden worker now. It uses a mutex so only one copy can run.
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%AUTODIR%\worker.ps1"

REM Perform an immediate update/deploy to verify everything now.
echo.
echo [3/4] Running the first update now...
call "%~dp0AUTO_UPDATE_NOW.cmd"
if errorlevel 1 (
  echo.
  echo The automatic updater was installed, but the first update failed.
  echo Log: "%AUTODIR%\auto-update.log"
  pause
  exit /b 2
)

for /f %%D in ('powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "(Get-Date).ToString('yyyy-MM-dd')"') do >"%AUTODIR%\last-success-day.txt" echo %%D

echo.
echo [4/4] Finished.
echo ============================================================
echo DONE - Administrator permission is NOT required.
echo Updates run every day at/after 07:00 AM while this user is logged in.
echo If the PC was off at 07:00, it updates after the next login.
echo The computer must have Internet access.
echo ============================================================
pause
exit /b 0
