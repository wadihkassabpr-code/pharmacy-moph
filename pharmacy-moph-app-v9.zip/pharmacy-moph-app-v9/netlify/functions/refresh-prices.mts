function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8' }
  });
}

function safeEquals(a: string, b: string) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

export default async (req: Request) => {
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);

  const expectedPin = Netlify.env.get('REFRESH_PIN') || '';
  const githubToken = Netlify.env.get('GITHUB_REFRESH_TOKEN') || '';
  const githubRepo = Netlify.env.get('GITHUB_REPO') || '';
  const workflowFile = Netlify.env.get('GITHUB_WORKFLOW_FILE') || 'daily-update.yml';
  const githubRef = Netlify.env.get('GITHUB_REF') || 'main';

  if (!expectedPin || !githubToken || !githubRepo) {
    console.error('Refresh is not configured. Missing REFRESH_PIN, GITHUB_REFRESH_TOKEN, or GITHUB_REPO.');
    return json({ error: 'التحديث السحابي غير مضبوط بعد.' }, 503);
  }

  let pin = '';
  try {
    const body = await req.json();
    pin = String(body?.pin || '');
  } catch {
    return json({ error: 'طلب غير صالح.' }, 400);
  }

  if (!safeEquals(pin, expectedPin)) return json({ error: 'رمز التحديث غير صحيح.' }, 401);

  const parts = githubRepo.split('/').map(x => x.trim()).filter(Boolean);
  if (parts.length !== 2) return json({ error: 'إعداد GITHUB_REPO غير صحيح.' }, 500);
  const [owner, repo] = parts;

  const url = `https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/actions/workflows/${encodeURIComponent(workflowFile)}/dispatches`;
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      accept: 'application/vnd.github+json',
      authorization: `Bearer ${githubToken}`,
      'x-github-api-version': '2022-11-28',
      'user-agent': 'pharmacy-moph-refresh'
    },
    body: JSON.stringify({ ref: githubRef })
  });

  if (response.status !== 204) {
    const detail = (await response.text()).slice(0, 600);
    console.error(`GitHub workflow dispatch failed: ${response.status} ${detail}`);
    return json({ error: `تعذر بدء التحديث السحابي (GitHub ${response.status}).` }, 502);
  }

  return json({ ok: true, message: 'تم إرسال طلب التحديث إلى الخادم السحابي.' }, 202);
};

export const config = {
  path: '/api/refresh-prices'
};
