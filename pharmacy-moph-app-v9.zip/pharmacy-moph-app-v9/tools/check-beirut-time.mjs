import { appendFileSync } from 'node:fs';

const dispatch = process.env.GITHUB_EVENT_NAME === 'workflow_dispatch';
const parts = new Intl.DateTimeFormat('en-CA', {
  timeZone: 'Asia/Beirut',
  year: 'numeric', month: '2-digit', day: '2-digit',
  hour: '2-digit', minute: '2-digit', hour12: false
}).formatToParts(new Date());
const p = Object.fromEntries(parts.map(x => [x.type, x.value]));
const hour = Number(p.hour);
const minute = Number(p.minute);
const local = `${p.year}-${p.month}-${p.day} ${p.hour}:${p.minute}`;
const shouldRun = dispatch || (hour === 7 && minute < 20);
console.log(`Beirut local time: ${local}`);
console.log(`Workflow event: ${process.env.GITHUB_EVENT_NAME || 'unknown'}`);
console.log(`Run update: ${shouldRun}`);
if (process.env.GITHUB_OUTPUT) {
  appendFileSync(process.env.GITHUB_OUTPUT, `run=${shouldRun}\nlocal=${local}\n`);
}
