$ErrorActionPreference = 'SilentlyContinue'
$base = Join-Path $env:LOCALAPPDATA 'PharmacyMophAutoUpdate'
New-Item -ItemType Directory -Force -Path $base | Out-Null
$pidFile = Join-Path $base 'worker.pid'
$log = Join-Path $base 'auto-update.log'

$createdNew = $false
$mutex = New-Object System.Threading.Mutex($true, 'Local\PharmacyMophAutoUpdateWorker', [ref]$createdNew)
if (-not $createdNew) { exit 0 }

Set-Content -Path $pidFile -Value $PID -Encoding ASCII
Add-Content -Path $log -Value "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Background updater started."

try {
    while ($true) {
        $now = Get-Date
        $today = $now.ToString('yyyy-MM-dd')
        $lastDayFile = Join-Path $base 'last-success-day.txt'
        $lastDay = ''
        if (Test-Path $lastDayFile) { $lastDay = (Get-Content $lastDayFile -First 1).Trim() }

        if ($now.Hour -ge 7 -and $lastDay -ne $today) {
            $cfg = Join-Path $base 'project-path.txt'
            if (Test-Path $cfg) {
                $project = (Get-Content $cfg -First 1).Trim()
                $updateCmd = Join-Path $project 'AUTO_UPDATE_NOW.cmd'
                if (Test-Path $updateCmd) {
                    Add-Content -Path $log -Value "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Daily update starting."
                    $proc = Start-Process -FilePath 'cmd.exe' -ArgumentList @('/d','/c',"`"$updateCmd`"") -WindowStyle Hidden -Wait -PassThru
                    if ($proc.ExitCode -eq 0) {
                        Set-Content -Path $lastDayFile -Value $today -Encoding ASCII
                        Add-Content -Path $log -Value "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Daily update completed."
                    } else {
                        Add-Content -Path $log -Value "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Daily update failed with exit code $($proc.ExitCode). Will retry later."
                    }
                }
            }
        }

        Start-Sleep -Seconds 300
    }
}
finally {
    Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
    if ($createdNew) { $mutex.ReleaseMutex() | Out-Null }
    $mutex.Dispose()
}
