import { mkdir, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';

const ORIGINS = ['https://www.moph.gov.lb', 'https://moph.gov.lb'];
const BASE_PATHS = [
  '/en/Drugs/index/3/7963',
  '/en/Drugs/index/0/23441',
  '/en/Drugs/index/0/7963',
  '/en/Drugs/index/0/10256',
  '/en/Drugs/index/3/4848'
];
const OUT = resolve('public/data/drugs.json');
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36';
let cookies = '';

const wait = ms => new Promise(r => setTimeout(r, ms));

function decodeEntities(input) {
  const map = { '&nbsp;': ' ', '&amp;': '&', '&quot;': '"', '&#39;': "'", '&lt;': '<', '&gt;': '>' };
  return input
    .replace(/&(nbsp|amp|quot|#39|lt|gt);/g, m => map[m] || m)
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)))
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCharCode(parseInt(n, 16)));
}

function textOf(html) {
  return decodeEntities(
    html
      .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, ' ')
      .replace(/<br\s*\/?\s*>/gi, ' ')
      .replace(/<[^>]+>/g, ' ')
  ).replace(/\s+/g, ' ').trim();
}

function parsePrice(text) {
  const digits = text.replace(/[^0-9]/g, '');
  return digits ? Number(digits) : null;
}

function parseRows(html) {
  const rows = [];
  const trRe = /<tr\b[^>]*>([\s\S]*?)<\/tr>/gi;
  let tr;
  while ((tr = trRe.exec(html))) {
    const cells = [];
    const tdRe = /<td\b[^>]*>([\s\S]*?)<\/td>/gi;
    let td;
    while ((td = tdRe.exec(tr[1]))) cells.push(textOf(td[1]));
    if (cells.length < 7) continue;
    const [atc, name, bg, ingredients, dosage, form, priceText] = cells;
    if (!name || /^name$/i.test(name)) continue;
    rows.push({ atc, name, bg, ingredients, dosage, form, price: parsePrice(priceText) });
  }
  return rows;
}

function maxPage(html) {
  let max = 1;
  const re = /page(?:%3A|:)(\d+)/gi;
  let m;
  while ((m = re.exec(html))) max = Math.max(max, Number(m[1]));
  return max;
}

function sourceLabel(html) {
  const plain = textOf(html);
  const en = plain.match(/Drugs Prices According to the Exchange Rate Issued on\s+([0-9/.-]+)/i);
  const ar = plain.match(/أسعار الأدوية[^\d]{0,100}([0-9]{1,2}\/[0-9]{1,2}\/[0-9]{4})/);
  return en?.[1] || ar?.[1] || '';
}

function updateCookies(res) {
  let setCookies = [];
  if (typeof res.headers.getSetCookie === 'function') setCookies = res.headers.getSetCookie();
  else {
    const one = res.headers.get('set-cookie');
    if (one) setCookies = [one];
  }
  const jar = new Map(cookies.split('; ').filter(Boolean).map(x => {
    const i = x.indexOf('=');
    return [x.slice(0, i), x.slice(i + 1)];
  }));
  for (const line of setCookies) {
    const pair = line.split(';', 1)[0];
    const i = pair.indexOf('=');
    if (i > 0) jar.set(pair.slice(0, i), pair.slice(i + 1));
  }
  cookies = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
}

async function fetchHtml(url, attempt = 1) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 25000);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      redirect: 'follow',
      headers: {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'accept-language': 'en-US,en;q=0.9,ar;q=0.7',
        'cache-control': 'no-cache',
        'pragma': 'no-cache',
        'upgrade-insecure-requests': '1',
        'user-agent': UA,
        ...(cookies ? { cookie: cookies } : {})
      }
    });
    updateCookies(res);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const html = await res.text();
    if (html.length < 1000) throw new Error('received an incomplete page');
    return html;
  } catch (err) {
    if (attempt < 4) {
      const delay = attempt * 1200;
      console.log(`  إعادة المحاولة بعد ${delay / 1000} ث... (${err.message})`);
      await wait(delay);
      return fetchHtml(url, attempt + 1);
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

async function warmUp(origin) {
  try { await fetchHtml(`${origin}/en/Pages/3/3010/pharmaceuticals`); } catch { /* optional */ }
}

async function chooseSource() {
  let last;
  for (const origin of ORIGINS) {
    await warmUp(origin);
    for (const base of BASE_PATHS) {
      const url = `${origin}${base}/page%3A1/sort%3ADrug.brand_name/direction%3Aasc`;
      try {
        console.log(`تجربة المصدر الرسمي: ${url}`);
        const html = await fetchHtml(url);
        const rows = parseRows(html);
        if (rows.length >= 5) return { origin, base, html, rows };
        last = new Error('لم أجد جدول الأدوية في الصفحة');
      } catch (err) {
        last = err;
        console.log(`  لم ينجح: ${err.message}`);
      }
    }
  }
  throw last || new Error('تعذر الوصول إلى موقع وزارة الصحة');
}

function uniqueRows(rows) {
  const seen = new Set();
  return rows.filter(r => {
    const key = [r.atc, r.name, r.ingredients, r.dosage, r.form, r.price ?? ''].map(x => String(x).trim().toLowerCase()).join('|');
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

async function main() {
  console.log('تحديث قاعدة الأدوية من وزارة الصحة اللبنانية...');
  console.log('يتم الاتصال من جهازك مباشرة لأن موقع الوزارة يمنع خوادم الاستضافة من القراءة الآلية.\n');

  const selected = await chooseSource();
  const pages = maxPage(selected.html);
  const all = [...selected.rows];
  const label = sourceLabel(selected.html);
  console.log(`\nالمصدر نجح. عدد الصفحات: ${pages}${label ? ` | مؤشر الأسعار: ${label}` : ''}`);

  for (let page = 2; page <= pages; page++) {
    const url = `${selected.origin}${selected.base}/page%3A${page}/sort%3ADrug.brand_name/direction%3Aasc`;
    process.stdout.write(`\rتحميل الصفحة ${page}/${pages}...`);
    const html = await fetchHtml(url);
    const rows = parseRows(html);
    if (!rows.length) throw new Error(`الصفحة ${page} لم تُرجع بيانات؛ أوقفت التحديث حتى لا نحفظ قاعدة ناقصة.`);
    all.push(...rows);
    await wait(120);
  }
  process.stdout.write('\n');

  const rows = uniqueRows(all).sort((a, b) => a.name.localeCompare(b.name, 'en', { sensitivity: 'base' }) || (a.price ?? Infinity) - (b.price ?? Infinity));
  await mkdir(dirname(OUT), { recursive: true });
  const payload = {
    source: 'Lebanon Ministry of Public Health',
    sourceUrl: `${selected.origin}${selected.base}`,
    sourcePriceIndexDate: label,
    synchronizedAt: new Date().toISOString(),
    count: rows.length,
    rows
  };
  await writeFile(OUT, JSON.stringify(payload));
  console.log(`تم بنجاح: ${rows.length} صنف دوائي.`);
  console.log(`تم حفظ الملف: ${OUT}`);
  console.log('\nاكتمل تحديث البيانات. سيقوم التحديث التلقائي بنشرها على Netlify.');
}

main().catch(err => {
  console.error('\nفشل التحديث:', err.message);
  console.error('إذا كان موقع الوزارة يفتح عندك في Chrome لكن هذا الأمر يعطي 403، أرسل لي صورة الخطأ وسأعطيك طريقة الاستيراد اليدوي من ملف Excel الرسمي.');
  process.exitCode = 1;
});
