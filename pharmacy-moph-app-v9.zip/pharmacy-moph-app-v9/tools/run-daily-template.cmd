@echo off
setlocal EnableExtensions
set "CFG=%LOCALAPPDATA%\PharmacyMophAutoUpdate\project-path.txt"
if not exist "%CFG%" exit /b 10
set /p PROJECT=<"%CFG%"
if not exist "%PROJECT%\AUTO_UPDATE_NOW.cmd" exit /b 11
call "%PROJECT%\AUTO_UPDATE_NOW.cmd"
if errorlevel 1 exit /b %errorlevel%
for /f %%D in ('powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "(Get-Date).ToString('yyyy-MM-dd')"') do >"%LOCALAPPDATA%\PharmacyMophAutoUpdate\last-success-day.txt" echo %%D
exit /b 0
