@echo off
setlocal EnableExtensions
set "BASE=%LOCALAPPDATA%\PharmacyMophAutoUpdate"
set "CFG=%BASE%\project-path.txt"
if not exist "%CFG%" exit /b 10

for /f %%D in ('powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "(Get-Date).ToString('yyyy-MM-dd')"') do set "TODAY=%%D"
for /f %%H in ('powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "(Get-Date).Hour"') do set "HOUR=%%H"
if %HOUR% LSS 7 exit /b 0

set "DONE="
if exist "%BASE%\last-success-day.txt" set /p DONE=<"%BASE%\last-success-day.txt"
if /I "%DONE%"=="%TODAY%" exit /b 0

set /p PROJECT=<"%CFG%"
if not exist "%PROJECT%\AUTO_UPDATE_NOW.cmd" exit /b 11
call "%PROJECT%\AUTO_UPDATE_NOW.cmd"
if errorlevel 1 exit /b %errorlevel%
>"%BASE%\last-success-day.txt" echo %TODAY%
exit /b 0
