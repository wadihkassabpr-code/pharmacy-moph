const input = document.getElementById('drugSearch');
const clearBtn = document.getElementById('clearBtn');
const statusEl = document.getElementById('status');
const suggestions = document.getElementById('suggestions');
const selectedSection = document.getElementById('selectedSection');
const alternativesSection = document.getElementById('alternativesSection');
const selectedName = document.getElementById('selectedName');
const selectedPrice = document.getElementById('selectedPrice');
const alternativesList = document.getElementById('alternativesList');
const altCount = document.getElementById('altCount');
const lastUpdated = document.getElementById('lastUpdated');

let debounceTimer;
let db = [];
let meta = null;
let dataReady = false;

const fmtPrice = value => {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? `${new Intl.NumberFormat('en-US').format(n)} ل.ل.` : 'السعر غير منشور';
};

function norm(s = '') {
  return String(s)
    .toLowerCase()
    .replace(/[µμ]/g, 'u')
    .replace(/[^a-z0-9%./+]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function ministryName(item) {
  const name = String(item?.name || '').trim();
  const dosage = String(item?.dosage || '').trim();
  if (!dosage) return name;
  const normalizedName = norm(name);
  const normalizedDosage = norm(dosage);
  if (normalizedDosage && normalizedName.includes(normalizedDosage)) return name;
  return `${name} ${dosage}`.trim();
}

const setStatus = (text = '', type = '') => {
  statusEl.className = `status ${type}`.trim();
  statusEl.innerHTML = text;
};

function resetResult() {
  selectedSection.hidden = true;
  alternativesSection.hidden = true;
  alternativesList.innerHTML = '';
}

async function loadData() {
  setStatus('<span class="loading-line">جاري تحميل قاعدة الأدوية...</span>');
  try {
    const res = await fetch('/data/drugs.json', { cache: 'no-cache' });
    if (!res.ok) throw new Error('missing data file');
    const data = await res.json();
    if (!Array.isArray(data.rows) || !data.rows.length) throw new Error('empty data file');
    db = data.rows.map(row => ({ ...row, _name: norm(row.name), _label: norm(ministryName(row)), _ingredients: norm(row.ingredients), _dosage: norm(row.dosage), _form: norm(row.form), _atc: norm(row.atc) }));
    meta = data;
    dataReady = true;
    setStatus(`جاهز للبحث في ${new Intl.NumberFormat('en-US').format(db.length)} صنف دوائي.`);
    const sync = data.synchronizedAt ? new Date(data.synchronizedAt).toLocaleString('ar-LB') : '';
    const idx = data.sourcePriceIndexDate ? ` | مؤشر الوزارة: ${data.sourcePriceIndexDate}` : '';
    lastUpdated.textContent = `${sync ? `آخر مزامنة: ${sync}` : ''}${idx}`;
  } catch {
    dataReady = false;
    setStatus('قاعدة الأدوية غير موجودة بعد. شغّل تحديث البيانات من الكمبيوتر ثم أعد نشر الموقع.', 'error');
  }
}

function showSuggestions(items) {
  suggestions.innerHTML = '';
  if (!items.length) {
    suggestions.hidden = true;
    setStatus('لم أجد دواءً مطابقاً في قاعدة وزارة الصحة المحفوظة.', '');
    return;
  }
  for (const item of items) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'suggestion';
    button.setAttribute('role', 'option');
    const name = document.createElement('span');
    name.className = 'name';
    name.textContent = ministryName(item);
    const price = document.createElement('span');
    price.className = 'price';
    price.textContent = fmtPrice(item.price);
    button.append(name, price);
    button.addEventListener('click', () => selectDrug(item));
    suggestions.appendChild(button);
  }
  suggestions.hidden = false;
  setStatus(`${items.length} نتيجة مطابقة`);
}

function runSearch(q) {
  if (!dataReady) {
    setStatus('قاعدة الأدوية غير جاهزة بعد.', 'error');
    return;
  }
  const nq = norm(q);
  const matches = db
    .filter(x => x._label.includes(nq) || x._name.includes(nq))
    .sort((a, b) => {
      const ar = a._label === nq ? 0 : a._label.startsWith(nq) ? 1 : a._name === nq ? 2 : a._name.startsWith(nq) ? 3 : 4;
      const br = b._label === nq ? 0 : b._label.startsWith(nq) ? 1 : b._name === nq ? 2 : b._name.startsWith(nq) ? 3 : 4;
      return ar - br || a._label.localeCompare(b._label) || (a.price ?? Infinity) - (b.price ?? Infinity);
    })
    .slice(0, 50);
  showSuggestions(matches);
}

function selectDrug(item) {
  input.value = ministryName(item);
  clearBtn.hidden = false;
  suggestions.hidden = true;
  selectedName.textContent = ministryName(item);
  selectedPrice.textContent = fmtPrice(item.price);
  selectedSection.hidden = false;
  alternativesSection.hidden = false;
  setStatus('');

  const matches = db
    .filter(x => !(x._name === item._name && Number(x.price) === Number(item.price)))
    .filter(x => x._ingredients && x._ingredients === item._ingredients)
    .filter(x => x._dosage === item._dosage)
    .filter(x => x._form === item._form)
    .filter(x => !item._atc || !x._atc || x._atc === item._atc);

  const seen = new Set();
  const alternatives = matches
    .filter(x => {
      const key = `${x._name}|${x.price ?? ''}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .sort((a, b) => (a.price ?? Infinity) - (b.price ?? Infinity) || a._name.localeCompare(b._name));
  renderAlternatives(alternatives);
}

function renderAlternatives(items) {
  altCount.textContent = `${items.length} بديل`;
  alternativesList.innerHTML = '';
  if (!items.length) {
    alternativesList.innerHTML = '<div class="empty">لا توجد بدائل مطابقة ضمن بيانات وزارة الصحة الحالية.</div>';
    return;
  }
  const firstPriced = items.findIndex(x => Number(x.price) > 0);
  items.forEach((item, index) => {
    const row = document.createElement('div');
    row.className = `alt-item ${index === firstPriced ? 'cheapest' : ''}`.trim();
    const nameWrap = document.createElement('div');
    nameWrap.className = 'alt-name';
    const name = document.createElement('strong');
    name.textContent = ministryName(item);
    nameWrap.appendChild(name);
    if (index === firstPriced) {
      const badge = document.createElement('span');
      badge.className = 'badge';
      badge.textContent = 'الأرخص';
      nameWrap.appendChild(badge);
    }
    const price = document.createElement('span');
    price.className = 'alt-price';
    price.textContent = fmtPrice(item.price);
    row.append(nameWrap, price);
    alternativesList.appendChild(row);
  });
}

input.addEventListener('input', () => {
  const q = input.value.trim();
  clearBtn.hidden = !q;
  clearTimeout(debounceTimer);
  resetResult();
  if (q.length < 2) {
    suggestions.hidden = true;
    setStatus(q ? 'اكتب حرفين على الأقل.' : (dataReady ? `جاهز للبحث في ${new Intl.NumberFormat('en-US').format(db.length)} صنف دوائي.` : 'قاعدة الأدوية غير جاهزة بعد.'));
    return;
  }
  debounceTimer = setTimeout(() => runSearch(q), 150);
});

input.addEventListener('keydown', e => {
  if (e.key === 'Enter') {
    const first = suggestions.querySelector('.suggestion');
    if (first && !suggestions.hidden) first.click();
  }
});

clearBtn.addEventListener('click', () => {
  input.value = '';
  clearBtn.hidden = true;
  suggestions.hidden = true;
  resetResult();
  setStatus(dataReady ? `جاهز للبحث في ${new Intl.NumberFormat('en-US').format(db.length)} صنف دوائي.` : 'قاعدة الأدوية غير جاهزة بعد.');
  input.focus();
});

async function clearLegacyOfflineCache() {
  try {
    if ('serviceWorker' in navigator) {
      const regs = await navigator.serviceWorker.getRegistrations();
      await Promise.all(regs.map(r => r.unregister()));
    }
    if ('caches' in window) {
      const keys = await caches.keys();
      await Promise.all(keys.map(k => caches.delete(k)));
    }
  } catch { /* best effort only */ }
}

clearLegacyOfflineCache().finally(loadData);
