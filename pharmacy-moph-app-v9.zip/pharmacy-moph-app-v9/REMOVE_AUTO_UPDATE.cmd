@echo off
setlocal EnableExtensions
set "BASE=%LOCALAPPDATA%\PharmacyMophAutoUpdate"
set "STARTFILE=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\PharmacyMophAutoUpdate.cmd"
if exist "%STARTFILE%" del /Q "%STARTFILE%" >nul 2>&1
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$p=Join-Path $env:LOCALAPPDATA 'PharmacyMophAutoUpdate\worker.pid'; if(Test-Path $p){$id=[int](Get-Content $p -First 1); Stop-Process -Id $id -Force -ErrorAction SilentlyContinue; Remove-Item $p -Force -ErrorAction SilentlyContinue}"
schtasks /Delete /TN "Pharmacy MOPH Daily Update" /F >nul 2>&1
schtasks /Delete /TN "Pharmacy MOPH Update Catchup" /F >nul 2>&1
echo Automatic pharmacy updates were removed for this Windows user.
pause
