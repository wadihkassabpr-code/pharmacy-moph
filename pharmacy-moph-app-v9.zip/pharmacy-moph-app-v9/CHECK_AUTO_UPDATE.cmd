@echo off
setlocal EnableExtensions
set "BASE=%LOCALAPPDATA%\PharmacyMophAutoUpdate"
set "STARTFILE=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\PharmacyMophAutoUpdate.cmd"
echo === Auto-start ===
if exist "%STARTFILE%" (echo INSTALLED: %STARTFILE%) else (echo NOT INSTALLED)
echo.
echo === Background worker ===
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$p=Join-Path $env:LOCALAPPDATA 'PharmacyMophAutoUpdate\worker.pid'; if(Test-Path $p){$id=[int](Get-Content $p -First 1); if(Get-Process -Id $id -ErrorAction SilentlyContinue){'RUNNING - PID '+$id}else{'PID file exists but worker is not running'}}else{'NOT RUNNING'}"
echo.
echo === Last log lines ===
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$p=Join-Path $env:LOCALAPPDATA 'PharmacyMophAutoUpdate\auto-update.log'; if(Test-Path $p){Get-Content $p -Tail 30}else{'No log yet.'}"
pause
