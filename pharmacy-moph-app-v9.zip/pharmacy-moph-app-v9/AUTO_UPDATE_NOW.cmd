@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "LOGDIR=%LOCALAPPDATA%\PharmacyMophAutoUpdate"
if not exist "%LOGDIR%" mkdir "%LOGDIR%" >nul 2>&1
set "LOG=%LOGDIR%\auto-update.log"

>>"%LOG%" echo.
>>"%LOG%" echo ============================================================
>>"%LOG%" echo [%date% %time%] Starting pharmacy MOPH update

echo.
echo [1/2] Updating medicine data from Lebanon MOPH...
call npm run update-data >>"%LOG%" 2>&1
if errorlevel 1 (
  echo.
  echo UPDATE FAILED. No deployment was made.
  echo Log: "%LOG%"
  >>"%LOG%" echo [%date% %time%] DATA UPDATE FAILED - deploy skipped
  exit /b 1
)

echo [2/2] Publishing updated data to Netlify...
call npx --yes netlify-cli deploy --prod >>"%LOG%" 2>&1
if errorlevel 1 (
  echo.
  echo DEPLOY FAILED. Data was updated locally but was not published.
  echo Log: "%LOG%"
  >>"%LOG%" echo [%date% %time%] NETLIFY DEPLOY FAILED
  exit /b 2
)

>"%LOGDIR%\last-success.txt" echo %date% %time%
>>"%LOG%" echo [%date% %time%] SUCCESS

echo.
echo SUCCESS: prices were updated and published.
echo Log: "%LOG%"
exit /b 0
